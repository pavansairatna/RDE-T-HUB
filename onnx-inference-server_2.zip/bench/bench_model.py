import os
import sys
import time
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "model"))
from featurize import hash_vectorize, DIM
import onnxruntime as ort

MODEL_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "model", "sentiment_int8.onnx")

samples = [
    "this laptop is absolutely fantastic and reliable",
    "the service was terrible and the food was awful",
    "honestly, the app is boring and buggy",
    "great flight, wonderful crew, highly recommend",
    "the update broke everything, very frustrating",
    "solid build quality for the price, impressed",
]


def pct(vals, p):
    vals = sorted(vals)
    k = (len(vals) - 1) * p / 100
    f = int(k)
    c = min(f + 1, len(vals) - 1)
    if f == c:
        return vals[f]
    return vals[f] + (vals[c] - vals[f]) * (k - f)


def main(n=5000, warmup=200):
    so = ort.SessionOptions()
    so.intra_op_num_threads = 1
    session = ort.InferenceSession(MODEL_PATH, sess_options=so, providers=["CPUExecutionProvider"])
    input_name = session.get_inputs()[0].name

    vecs = [hash_vectorize(t, DIM).reshape(1, -1) for t in samples]

    dummy = np.zeros((1, DIM), dtype=np.float32)
    for _ in range(warmup):
        session.run(None, {input_name: dummy})

    hash_times = []
    for i in range(n):
        t0 = time.perf_counter()
        hash_vectorize(samples[i % len(samples)], DIM)
        hash_times.append((time.perf_counter() - t0) * 1000)

    infer_times = []
    for i in range(n):
        v = vecs[i % len(vecs)]
        t0 = time.perf_counter()
        session.run(None, {input_name: v})
        infer_times.append((time.perf_counter() - t0) * 1000)

    full_times = []
    for i in range(n):
        t0 = time.perf_counter()
        v = hash_vectorize(samples[i % len(samples)], DIM).reshape(1, -1)
        session.run(None, {input_name: v})
        full_times.append((time.perf_counter() - t0) * 1000)

    for name, vals in [("hashing only", hash_times), ("infer only", infer_times), ("hash + infer", full_times)]:
        print(f"{name:15s} p50={pct(vals,50):.4f}ms p95={pct(vals,95):.4f}ms p99={pct(vals,99):.4f}ms max={max(vals):.4f}ms")


if __name__ == "__main__":
    main()
