import argparse
import time
import httpx

samples = [
    "this laptop is absolutely fantastic and reliable",
    "the service was terrible and the food was awful",
    "honestly, the app is boring and buggy",
    "great flight, wonderful crew, highly recommend",
    "the update broke everything, very frustrating",
    "solid build quality for the price, impressed",
]


def pct(vals, p):
    vals = sorted(vals)
    k = (len(vals) - 1) * p / 100
    f = int(k)
    c = min(f + 1, len(vals) - 1)
    if f == c:
        return vals[f]
    return vals[f] + (vals[c] - vals[f]) * (k - f)


def report(name, vals):
    print(f"{name} n={len(vals)} p50={pct(vals,50):.3f}ms p95={pct(vals,95):.3f}ms p99={pct(vals,99):.3f}ms max={max(vals):.3f}ms")


def run_sequential(url, n, warmup):
    with httpx.Client(base_url=url, timeout=5.0) as c:
        for i in range(warmup):
            c.post("/predict", json={"text": samples[i % len(samples)]})

        times = []
        for i in range(n):
            t0 = time.perf_counter()
            r = c.post("/predict", json={"text": samples[i % len(samples)]})
            times.append((time.perf_counter() - t0) * 1000)
            assert r.status_code == 200
        return times


def run_concurrent(url, n, conc, warmup):
    import concurrent.futures as cf

    with httpx.Client(base_url=url, timeout=5.0, limits=httpx.Limits(max_connections=conc)) as c:
        for i in range(warmup):
            c.post("/predict", json={"text": samples[i % len(samples)]})

        def one(i):
            t0 = time.perf_counter()
            r = c.post("/predict", json={"text": samples[i % len(samples)]})
            assert r.status_code == 200
            return (time.perf_counter() - t0) * 1000

        start = time.perf_counter()
        times = []
        with cf.ThreadPoolExecutor(max_workers=conc) as ex:
            for t in ex.map(one, range(n)):
                times.append(t)
        wall = time.perf_counter() - start
        print(f"conc={conc} wall={wall:.2f}s throughput={n/wall:.0f} req/s")
        return times


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", default="http://127.0.0.1:8000")
    ap.add_argument("--n", type=int, default=3000)
    ap.add_argument("--warmup", type=int, default=100)
    ap.add_argument("--concurrency", type=int, default=0)
    args = ap.parse_args()

    if args.concurrency > 1:
        t = run_concurrent(args.url, args.n, args.concurrency, args.warmup)
        report(f"conc={args.concurrency}", t)
    else:
        t = run_sequential(args.url, args.n, args.warmup)
        report("sequential", t)
