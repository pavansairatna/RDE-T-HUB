import random

# just making up sentences from templates so i don't need to download a dataset

good_words = ["amazing","fantastic","wonderful","excellent","great","delightful",
    "superb","brilliant","outstanding","impressive","lovely","solid",
    "terrific","awesome","flawless","charming","reliable","polished"]

bad_words = ["terrible","awful","horrible","disappointing","mediocre","bad",
    "dreadful","clunky","buggy","frustrating","overpriced","boring",
    "sloppy","unreliable","broken","annoying","underwhelming","poor"]

filler = ["honestly","to be fair","overall","in my opinion","frankly",
    "after using it a while","compared to last year's model"]

things = ["the product","this movie","the food","the service","the app",
    "this book","the hotel","the laptop","the phone","the show",
    "this restaurant","the flight","the camera","the software",
    "this game","the course","the headphones","the update"]

pos_templates = [
    "{f}, {n} was {a}.",
    "{n} is {a} and I would recommend it.",
    "I really enjoyed {n}, it was {a}.",
    "{n} exceeded my expectations, {a} experience overall.",
    "Absolutely {a} - {n} made my day.",
    "{n} works great, {a} quality for the price.",
]
neg_templates = [
    "{f}, {n} was {a}.",
    "{n} is {a}, I would not recommend it.",
    "I was disappointed by {n}, it felt {a}.",
    "{n} fell short of expectations, {a} experience overall.",
    "Honestly {a} - {n} ruined my day.",
    "{n} barely works, {a} quality for the price.",
]

def make_sentence(template, word_list, rng):
    return template.format(f=rng.choice(filler), n=rng.choice(things), a=rng.choice(word_list))

def generate(n_per_class=1500, seed=13):
    rng = random.Random(seed)
    texts = []
    labels = []
    for i in range(n_per_class):
        texts.append(make_sentence(rng.choice(pos_templates), good_words, rng))
        labels.append(1)
        texts.append(make_sentence(rng.choice(neg_templates), bad_words, rng))
        labels.append(0)
    # shuffle together
    zipped = list(zip(texts, labels))
    rng.shuffle(zipped)
    texts, labels = zip(*zipped)
    return list(texts), list(labels)

if __name__ == "__main__":
    t, l = generate(5)
    for a, b in zip(t, l):
        print(b, a)
