import re
import numpy as np

# using hashing trick so we don't need to save/load a vocab file
DIM = 4096

token_re = re.compile(r"[a-z0-9']+")

def tokenize(text):
    return token_re.findall(text.lower())

# basic fnv hash, nothing fancy
def fnv1a(s):
    h = 0x811C9DC5
    for b in s.encode("utf-8"):
        h ^= b
        h = (h * 0x01000193) & 0xFFFFFFFF
    return h

def hash_vectorize(text, dim=DIM):
    vec = np.zeros(dim, dtype=np.float32)
    mask = dim - 1
    for tok in tokenize(text):
        h = fnv1a(tok)
        idx = h & mask
        sign = 1.0 if (h >> 31) & 1 else -1.0
        vec[idx] += sign
    n = np.linalg.norm(vec)
    if n > 0:
        vec = vec / n
    return vec

def hash_vectorize_batch(texts, dim=DIM):
    out = np.zeros((len(texts), dim), dtype=np.float32)
    for i, t in enumerate(texts):
        out[i] = hash_vectorize(t, dim)
    return out
