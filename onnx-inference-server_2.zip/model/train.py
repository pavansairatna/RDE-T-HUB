import os
import time
import numpy as np
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

from data_gen import generate
from featurize import hash_vectorize_batch, DIM

here = os.path.dirname(os.path.abspath(__file__))
fp32_path = os.path.join(here, "sentiment_fp32.onnx")
int8_path = os.path.join(here, "sentiment_int8.onnx")

def main():
    print("making dataset...")
    texts, labels = generate(n_per_class=1500)
    y = np.array(labels, dtype=np.int64)

    print("vectorizing...")
    t0 = time.time()
    X = hash_vectorize_batch(texts)
    print("took", time.time() - t0, "sec, shape", X.shape)

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=13, stratify=y)

    print("training...")
    clf = MLPClassifier(hidden_layer_sizes=(64,), activation="relu", alpha=1e-4,
                         max_iter=200, random_state=13, early_stopping=True, n_iter_no_change=8)
    clf.fit(X_train, y_train)

    acc = accuracy_score(y_test, clf.predict(X_test))
    print("test accuracy:", acc)

    print("exporting onnx...")
    from skl2onnx import to_onnx
    from skl2onnx.common.data_types import FloatTensorType

    onx = to_onnx(clf, initial_types=[("input", FloatTensorType([None, DIM]))],
                  target_opset=17, options={id(clf): {"zipmap": False}})

    with open(fp32_path, "wb") as f:
        f.write(onx.SerializeToString())
    print("wrote", fp32_path, os.path.getsize(fp32_path), "bytes")

    print("quantizing...")
    from onnxruntime.quantization import quantize_dynamic, QuantType
    quantize_dynamic(model_input=fp32_path, model_output=int8_path, weight_type=QuantType.QInt8)
    print("wrote", int8_path, os.path.getsize(int8_path), "bytes")

    # quick sanity check that quantized model didn't break anything
    import onnxruntime as ort
    s1 = ort.InferenceSession(fp32_path, providers=["CPUExecutionProvider"])
    s2 = ort.InferenceSession(int8_path, providers=["CPUExecutionProvider"])
    sample = X_test[:200]
    sk_pred = clf.predict(sample)
    p1 = s1.run(None, {"input": sample})[0]
    p2 = s2.run(None, {"input": sample})[0]
    print("fp32 agrees with sklearn:", (p1 == sk_pred).mean())
    print("int8 agrees with sklearn:", (p2 == sk_pred).mean())

if __name__ == "__main__":
    main()
